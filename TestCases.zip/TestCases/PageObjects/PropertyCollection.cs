﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INCA_ApplicationProject.INCA_Application.SwedBank.TestCases.PageObjects
{

    enum PropertType
    {
        Id,
        Name,
        LinkText,
        PartialLinkText,
        ClassName

    }
    public class PropertyCollection
    {
        public static IWebDriver driver { get; set; }
    }
}