﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INCA_ApplicationProject.INCA_Application.SwedBank.TestCases.PageObjects
{
    public class INCAHomeScreen
    {

        public IWebElement searchOrganizationField => PropertyCollection.driver.FindElement(By.Id("navSearchField"));
        public IWebElement searchOrganizationButton => PropertyCollection.driver.FindElement(By.Id("navSearchButton"));
    }
}