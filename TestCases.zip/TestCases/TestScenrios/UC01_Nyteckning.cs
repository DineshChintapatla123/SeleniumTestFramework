﻿using INCA_ApplicationProject.INCA_Application.SwedBank.TestCases.Common_methods;
using INCA_ApplicationProject.INCA_Application.SwedBank.TestCases.PageObjects;
using INCA_ApplicationProject.INCA_Application.SwedBank.TestCases.TestData;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INCA_ApplicationProject.INCA_Application.SwedBank.TestCases.TestScenrios
{
    public class UC01_Nyteckning
    {

        [SetUp]
        public void SeleniumSetup()
        {
            CommonMethods common = new CommonMethods();
            common.Intialize();
            
        }



        [Test]
        public void TC01_AddingCompany()
        {

            INCAHomeScreen home = new INCAHomeScreen();
            home.searchOrganizationField.SendKeys(UC01_TestData.organisationNumber);
            home.searchOrganizationButton.Click();
        }

        [TearDown]
        public void quit()
        {
            Console.WriteLine("clode the driver");
            PropertyCollection.driver.Quit();
        }
    }
}