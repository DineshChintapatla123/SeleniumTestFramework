﻿using INCA_ApplicationProject.INCA_Application.SwedBank.TestCases.PageObjects;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INCA_ApplicationProject.INCA_Application.SwedBank.TestCases.Common_methods
{
    public class CommonMethods
    { 


        public void Intialize()
        {
            PropertyCollection.driver = new ChromeDriver();

            // Navigating to the INCA website
            PropertyCollection.driver.Navigate().GoToUrl("http://inca-stm.swedbank.net:1118/vertigo/vertigo/GOPerson/GOPerson/mainFrameset ");
            Console.WriteLine("navigating to the URL");
            PropertyCollection.driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);

        }
    }
}