﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INCA_ApplicationProject.INCA_Application.SwedBank.TestCases.TestData
{
    public class UC01_TestData
    {
        //Test Case 1
        public static string organisationNumber = "XX"; //5564398120
        public static string companyName = "Company One AB";
        public static string annualAccountDate = "0101";
        public static string addressRow1 = "Stora Essingen";
        public static string postCode = "11261";
        public static string city = "Stockholm";




        //Test Case 2
        public static string pensionPlanName = "Test1 Pensionsplan";
        public static string contractStartDate = "20180101";
        public static string contractResponsible = "p732abc";
        public static string agentNumber = "10123";

        //Test Case 3
        public static string newBenefitGroupId = "11"; //	TRPP Företagare Sjuk Utom Procent av lön
        public static string benefitGroupFirst = "Företagare 1";
        public static string benefitGroupSecond = "Företagare 2";
        public static string insuranceProductName = "Tjänstepension Fond";
        public static string selectPremiumName = "% av lön";
        public static string premiumCalculationName = "4,5% av lön";
        public static string premiumCalculationAmount = "0,045";

        //Test Case 4
        public static string personalNumber = "XXAUTO_ID3325506";
        public static string employmentCategory = "Anställd";
        public static string employmentStartDate = "20180201";
        public static string employmentbenefitGroupCategory = "Anställd (T) TRPP Anställd Sjuk Inom Procent av lön";
        public static string employmentSalary = "400000";

        //Test Case 5
        public static string employmentNavTree = "Anställning";
        public static string riskAssessmentStatus = "Godkänt";

        //Test Case 6
        public static string invoiceStatus = "Debiteringsunderlag ej kopplade till faktura";
    }
}